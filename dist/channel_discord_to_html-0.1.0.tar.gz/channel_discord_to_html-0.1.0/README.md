# Discord Channel to HTML

`discord-channel-to-html` is a Python library for translating Discord channel data into beautiful, self-contained HTML files.

This library is designed to be a **translator**, not a data collector. It takes native `discord.py` objects as input and returns an HTML string, leaving the task of fetching data to your bot. This decoupled approach makes the library lightweight and flexible.

## Features

-   **Complete Message Support:** Handles text, embeds, attachments, stickers, replies, and system messages.
-   **Thread Support:** Correctly displays transcripts from threads with contextual headers.
-   **Dark Theme:** Comes with a clean, modern dark theme inspired by Discord.
-   **Bilingual:** Generated elements like timestamps and system messages can be in English or French.
-   **Self-Contained:** The generated HTML file has all CSS embedded, making it a single, portable file.
-   **Markdown Support:** Message content is rendered from Markdown to HTML, preserving formatting like bold, italics, code blocks, and more.

## Installation

```bash
pip install discord-channel-to-html
```

*(Note: The library is not yet on PyPI. This is the command you will use once it is published.)*

You will also need `discord.py` in your environment.

```bash
pip install discord.py
```

## Usage

The library is simple to use. Your bot collects the messages, and you pass them to the `generate_transcript` function.

Here is a basic example within a `discord.py` slash command:

```python
import discord
from discord_channel_to_html import generate_transcript
import os

# Inside a slash command or other event...
async def create_transcript(ctx: discord.ApplicationContext):

    # 1. Acknowledge the command
    await ctx.defer()

    # 2. Fetch messages from the channel
    messages = await ctx.channel.history(limit=250).flatten()

    if not messages:
        await ctx.respond("No messages to transcribe.", ephemeral=True)
        return

    # 3. Generate the transcript HTML
    # The `channel` object provides context for the header (name, topic, etc.)
    html_content = generate_transcript(
        channel=ctx.channel,
        messages=messages,
        lang='en'  # or 'fr'
    )

    # 4. Save to a file
    file_path = f"transcript-{ctx.channel.id}.html"
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    # 5. Send the file
    await ctx.respond("Here is your transcript:", file=discord.File(file_path))

    # 6. (Optional) Clean up the file
    os.remove(file_path)
```

### Customization

The `generate_transcript` function accepts a few options for customization:

-   `lang`: (str) The language for timestamps and system messages. Can be `'en'` (default) or `'fr'`.

## Contributing

Contributions are welcome! If you have a feature request, bug report, or pull request, please open an issue on the [GitHub repository](https://github.com/your-github/discord-channel-to-html).

## License

This project is licensed under the MIT License.
