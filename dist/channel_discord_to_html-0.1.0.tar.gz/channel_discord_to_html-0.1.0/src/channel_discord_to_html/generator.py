import discord
import html
from markdown_it import MarkdownIt
from .locales import LOCALES

md = MarkdownIt()

def generate_transcript(channel: discord.TextChannel, messages: list[discord.Message], lang: str = 'en') -> str:
    """
    Generates an HTML transcript from a list of Discord messages.
    """
    locale = LOCALES.get(lang, LOCALES['en'])
    
    transcript_header = f"""
    <div class="transcript-header">
        <h1>#{html.escape(channel.name)}</h1>
        <p>{html.escape(channel.topic) if channel.topic else ''}</p>
    </div>
    """
    
    message_html = ""
    for message in reversed(messages):
        message_html += _generate_message_html(message, locale)
        
    with open("src/channel_discord_to_html/static/style.css", "r", encoding="utf-8") as f:
        css_content = f.read()

    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Transcript of #{html.escape(channel.name)}</title>
        <style>
            {css_content}
        </style>
    </head>
    <body>
        <div class="transcript-container">
            {transcript_header}
            {message_html}
        </div>
    </body>
    </html>
    """

def _generate_message_html(message: discord.Message, locale: dict) -> str:
    """
    Generates the HTML for a single message.
    """
    if message.is_system():
        return _generate_system_message_html(message, locale)

    author_avatar = message.author.display_avatar.url
    author_name = message.author.display_name
    timestamp = message.created_at.strftime(locale['timestamp_format'])
    
    message_content = ""
    if message.content:
        message_content = md.render(message.content)

    reply_html = ""
    if message.reference and message.reference.resolved:
        reply_html = _generate_reply_html(message.reference.resolved, locale)

    embed_html = "".join([_generate_embed_html(embed) for embed in message.embeds])
    attachment_html = "".join([_generate_attachment_html(attachment) for attachment in message.attachments])
    sticker_html = "".join([_generate_sticker_html(sticker) for sticker in message.stickers])

    return f"""
    <div class="message-group">
        <div class="author-avatar">
            <img src="{author_avatar}" alt="Avatar">
        </div>
        <div class="message-content">
            <div class="author-details">
                <span class="author-name">{html.escape(author_name)}</span>
                <span class="timestamp">{timestamp}</span>
            </div>
            {reply_html}
            <div class="message-text">{message_content}</div>
            {embed_html}
            {attachment_html}
            {sticker_html}
        </div>
    </div>
    """

def _generate_reply_html(message: discord.Message, locale: dict) -> str:
    """
    Generates the HTML for a reply.
    """
    author_avatar = message.author.display_avatar.url
    author_name = message.author.display_name
    content = message.content if message.content else "Click to see attachment"

    return f"""
    <div class="reply-info">
        <img src="{author_avatar}" alt="Avatar">
        <span class="reply-author">{html.escape(author_name)}</span>
        <div class="reply-content">{content}</div>
    </div>
    """

def _generate_embed_html(embed: discord.Embed) -> str:
    """
    Generates the HTML for an embed.
    """
    embed_color = f"border-left-color: {embed.color};" if embed.color else ""
    
    title_html = f"<div class='embed-title'><strong>{embed.title}</strong></div>" if embed.title else ""
    description_html = f"<div class='embed-description'>{md.render(embed.description)}</div>" if embed.description else ""
    
    fields_html = "<div class='embed-fields'>"
    for field in embed.fields:
        fields_html += f"""
        <div class='embed-field'>
            <div class='embed-field-name'>{field.name}</div>
            <div class='embed-field-value'>{md.render(field.value)}</div>
        </div>
        """
    fields_html += "</div>"

    image_html = f"<div class='embed-image'><img src='{embed.image.url}' alt='Embed Image'></div>" if embed.image else ""
    
    footer_html = ""
    if embed.footer:
        footer_icon_html = f"<img src='{embed.footer.icon_url}' alt='Footer Icon'>" if embed.footer.icon_url else ""
        footer_html = f"""
        <div class='embed-footer'>
            {footer_icon_html}
            <span>{embed.footer.text}</span>
        </div>
        """

    return f"""
    <div class='embed' style='{embed_color}'>
        {title_html}
        {description_html}
        {fields_html}
        {image_html}
        {footer_html}
    </div>
    """

def _generate_attachment_html(attachment: discord.Attachment) -> str:
    """
    Generates the HTML for an attachment.
    """
    if attachment.content_type.startswith("image/"):
        return f"<div class='attachment-image'><img src='{attachment.url}' alt='Attachment'></div>"
    elif attachment.content_type.startswith("video/"):
        return f"<div class='attachment-video'><video controls src='{attachment.url}'></video></div>"
    else:
        return f"""
        <div class='attachment-file'>
            <a href='{attachment.url}' target='_blank'>{attachment.filename}</a>
            <div class='attachment-file-details'>
                <span class='attachment-file-size'>{round(attachment.size / 1024, 2)} KB</span>
            </div>
        </div>
        """

def _generate_sticker_html(sticker: discord.StickerItem) -> str:
    """
    Generates the HTML for a sticker.
    """
    return f"<div class='sticker-item'><img src='{sticker.url}' alt='{sticker.name}'></div>"

def _generate_system_message_html(message: discord.Message, locale: dict) -> str:
    """
    Generates the HTML for a system message.
    """
    if message.type == discord.MessageType.pins_add:
        user = html.escape(message.author.display_name)
        return f"<div class='system-message'>{locale['system_message_pin'].format(user=user)}</div>"
    elif message.type == discord.MessageType.thread_created:
        user = html.escape(message.author.display_name)
        thread_name = html.escape(message.thread.name)
        return f"<div class='system-message'>{locale['thread_created'].format(user=user, thread_name=thread_name)}</div>"
    elif message.type == discord.MessageType.channel_name_change:
        user = html.escape(message.author.display_name)
        new_name = html.escape(message.channel.name)
        return f"<div class='system-message'>{locale['channel_name_change'].format(user=user, new_name=new_name)}</div>"
    return ""