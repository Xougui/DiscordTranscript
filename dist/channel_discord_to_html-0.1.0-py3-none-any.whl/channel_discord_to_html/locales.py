LOCALES = {
    'en': {
        'timestamp_format': '%d/%m/%Y at %H:%M',
        'system_message_pin': '📌 {user} pinned a message to this channel.',
        'thread_created': '💬 {user} started a thread: {thread_name}',
        'channel_name_change': '📝 {user} changed the channel name: {new_name}'
    },
    'fr': {
        'timestamp_format': 'le %d/%m/%Y à %H:%M',
        'system_message_pin': '📌 {user} a épinglé un message dans ce salon.',
        'thread_created': '💬 {user} a démarré un fil : {thread_name}',
        'channel_name_change': '📝 {user} a changé le nom du salon en : {new_name}'
    }
}
